package dev.threejsnative.engine

import android.content.Context
import android.graphics.SurfaceTexture
import android.util.AttributeSet
import android.view.InputDevice
import android.view.MotionEvent
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.TextureView

/** Default composited host view. The SurfaceView adapter below is available for device A/B tests. */
public class TjnEngineView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : TextureView(context, attrs), TextureView.SurfaceTextureListener {
    private var engine: TjnEngine? = null
    private var nativeSurface: Surface? = null
    private var surfaceAttached = false
    private var activePointers = 0

    init {
        surfaceTextureListener = this
        isFocusable = true
        isFocusableInTouchMode = true
    }

    internal fun bind(value: TjnEngine?) {
        if (engine === value) return
        detachSurface()
        engine = value
        if (value != null && isAvailable) surfaceTexture?.let { attachSurface(it, width, height) }
    }

    private fun attachSurface(texture: SurfaceTexture, width: Int, height: Int) {
        if (engine == null || surfaceAttached || width <= 0 || height <= 0) return
        texture.setDefaultBufferSize(width, height)
        val surface = Surface(texture)
        val density = resources.displayMetrics.density.coerceAtLeast(1f)
        try {
            engine?.surfaceAvailable(surface, (width / density).toInt(), (height / density).toInt(),
                width, height, density)
            nativeSurface = surface
            surfaceAttached = true
        } catch (error: Throwable) {
            surface.release()
            throw error
        }
    }

    private fun detachSurface() {
        if (surfaceAttached) engine?.surfaceDestroyed()
        surfaceAttached = false
        nativeSurface?.release()
        nativeSurface = null
    }

    override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) =
        attachSurface(surface, width, height)

    override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {
        if (width <= 0 || height <= 0) return
        surface.setDefaultBufferSize(width, height)
        val density = resources.displayMetrics.density.coerceAtLeast(1f)
        engine?.surfaceChanged((width / density).toInt(), (height / density).toInt(),
            width, height, density)
    }

    override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
        detachSurface()
        return true
    }

    override fun onSurfaceTextureUpdated(surface: SurfaceTexture) = Unit

    override fun onTouchEvent(event: MotionEvent): Boolean = dispatchPointer(event, engine)

    override fun onHoverEvent(event: MotionEvent): Boolean {
        engine?.pointer(2, event.getPointerId(0), event.x, event.y, event.pressure,
            event.buttonState, event.metaState)
        return engine != null
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (event.isFromSource(InputDevice.SOURCE_CLASS_POINTER) && event.action == MotionEvent.ACTION_SCROLL) {
            engine?.wheel(-event.getAxisValue(MotionEvent.AXIS_VSCROLL) * 48f)
            return engine != null
        }
        return super.onGenericMotionEvent(event)
    }

    private fun dispatchPointer(event: MotionEvent, target: TjnEngine?): Boolean {
        target ?: return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> activePointers++
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP ->
                activePointers = (activePointers - 1).coerceAtLeast(0)
            MotionEvent.ACTION_CANCEL -> activePointers = 0
        }
        parent?.requestDisallowInterceptTouchEvent(activePointers > 0)
        val kind = when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> 1
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> 3
            MotionEvent.ACTION_CANCEL -> 4
            else -> 2
        }
        for (index in 0 until event.pointerCount) {
            target.pointer(kind, event.getPointerId(index), event.getX(index), event.getY(index),
                event.getPressure(index), event.buttonState, event.metaState)
        }
        return true
    }
}

/** Optional lower-composition-cost adapter for fixed-device TextureView/SurfaceView A/B tests. */
public class TjnEngineSurfaceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : SurfaceView(context, attrs), SurfaceHolder.Callback {
    private var engine: TjnEngine? = null
    private var surfaceAttached = false
    private var activePointers = 0

    init {
        holder.addCallback(this)
        isFocusable = true
        isFocusableInTouchMode = true
    }

    public fun bindEngine(value: TjnEngine?) = bind(value)

    internal fun bind(value: TjnEngine?) {
        if (engine === value) return
        if (surfaceAttached) engine?.surfaceDestroyed()
        surfaceAttached = false
        engine = value
        if (value != null && holder.surface.isValid) attachSurface(width, height)
    }

    private fun attachSurface(width: Int, height: Int) {
        if (engine == null || surfaceAttached || !holder.surface.isValid || width <= 0 || height <= 0) return
        val density = resources.displayMetrics.density.coerceAtLeast(1f)
        engine?.surfaceAvailable(holder.surface, (width / density).toInt(), (height / density).toInt(),
            width, height, density)
        surfaceAttached = true
    }

    override fun surfaceCreated(holder: SurfaceHolder) = attachSurface(width, height)

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        if (!surfaceAttached) {
            attachSurface(width, height)
            return
        }
        val density = resources.displayMetrics.density.coerceAtLeast(1f)
        engine?.surfaceChanged((width / density).toInt(), (height / density).toInt(),
            width, height, density)
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        if (surfaceAttached) engine?.surfaceDestroyed()
        surfaceAttached = false
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val target = engine ?: return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> activePointers++
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP ->
                activePointers = (activePointers - 1).coerceAtLeast(0)
            MotionEvent.ACTION_CANCEL -> activePointers = 0
        }
        parent?.requestDisallowInterceptTouchEvent(activePointers > 0)
        val kind = when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> 1
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> 3
            MotionEvent.ACTION_CANCEL -> 4
            else -> 2
        }
        for (index in 0 until event.pointerCount) {
            target.pointer(kind, event.getPointerId(index), event.getX(index), event.getY(index),
                event.getPressure(index), event.buttonState, event.metaState)
        }
        return true
    }

    override fun onHoverEvent(event: MotionEvent): Boolean {
        engine?.pointer(2, event.getPointerId(0), event.x, event.y, event.pressure,
            event.buttonState, event.metaState)
        return engine != null
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (event.isFromSource(InputDevice.SOURCE_CLASS_POINTER) && event.action == MotionEvent.ACTION_SCROLL) {
            engine?.wheel(-event.getAxisValue(MotionEvent.AXIS_VSCROLL) * 48f)
            return engine != null
        }
        return super.onGenericMotionEvent(event)
    }
}
