// AUTO-GENERATED from bindings/idl/engine.tjnidl.ts. DO NOT EDIT.
package dev.threejsnative.engine.generated

public object TjnEngineAbi {
    public const val VERSION: Int = 1
    public const val COMPATIBILITY_REVISION: Int = 1
}

public object TjnStatus {
    const val OK: Int = 0
    const val INVALID_ARGUMENT: Int = 1
    const val INVALID_STATE: Int = 2
    const val ABI_MISMATCH: Int = 3
    const val CAPACITY_EXCEEDED: Int = 4
    const val INVALID_HANDLE: Int = 5
    const val STALE_HANDLE: Int = 6
    const val TYPE_MISMATCH: Int = 7
    const val WRONG_SESSION: Int = 8
    const val UNSUPPORTED_FEATURE: Int = 9
    const val SURFACE_UNAVAILABLE: Int = 10
    const val ASSET_INVALID: Int = 11
    const val INTEGRITY_MISMATCH: Int = 12
    const val CANCELLED: Int = 13
    const val TIMED_OUT: Int = 14
    const val BUFFER_TOO_SMALL: Int = 15
    const val QUEUE_OVERFLOW: Int = 16
    const val OUT_OF_MEMORY: Int = 17
    const val CONTEXT_LOST: Int = 18
    const val INTERNAL: Int = 19
    const val NO_EVENT: Int = 20
    const val WOULD_BLOCK: Int = 21
}
