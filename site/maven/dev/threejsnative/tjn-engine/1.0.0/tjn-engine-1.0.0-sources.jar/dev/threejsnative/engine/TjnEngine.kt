package dev.threejsnative.engine

import android.content.ComponentCallbacks2
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Choreographer
import android.view.Surface
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import dev.threejsnative.engine.generated.TjnStatus
import java.io.Closeable
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.coroutineContext

public enum class EngineState { Detached, Attaching, SurfaceReady, Running, Suspended, Failed, Destroying, Destroyed }
public data class EngineConfiguration(val eventCapacity: Int = 256, val memoryBudgetBytes: Long = 512L shl 20,
                                      val quality: Int = 1) {
    public companion object { public val StandardMobile: EngineConfiguration = EngineConfiguration() }
}
public data class RuntimeCapabilities(val backend: Int, val maxTextureSize: Int,
                                      val maxRenderTargetSize: Int, val enabledFeatures: Long)
public data class PerspectiveCameraConfiguration(val fovDegrees: Float = 45f, val aspect: Float,
                                                  val nearPlane: Float = .1f, val farPlane: Float = 100f)
public sealed interface GeometryDescriptor { public data class Box(val width: Float, val height: Float, val depth: Float) : GeometryDescriptor }
public sealed interface MaterialDescriptor {
    public data class Basic(val colorRgb: Int) : MaterialDescriptor
    public data class Standard(val colorRgb: Int, val metalness: Float = 0f, val roughness: Float = 1f) : MaterialDescriptor
}
public sealed interface LightDescriptor {
    public data class Ambient(val colorRgb: Int, val intensity: Float) : LightDescriptor
    public data class Directional(val colorRgb: Int, val intensity: Float) : LightDescriptor
    public data class Point(val colorRgb: Int, val intensity: Float, val distance: Float) : LightDescriptor
}
public data class AssetRequest(val uri: Uri)
public data class CaptureOptions(val renderTarget: TjnRenderTarget? = null)
public enum class SuspensionReason(internal val value: Int) { Explicit(0), ApplicationInactive(1) }
public enum class TrimMemoryLevel { Moderate, Critical }
public data class EngineEvent(val type: Int, val requestId: Long, val objectHandle: Long, val status: Int,
                              val value0: Long, val value1: Long)
public class TjnEngineException(public val status: Int, operation: String) :
    IllegalStateException("$operation failed with status $status")

internal fun <T> requestDeferred(caller: Job?): CompletableDeferred<T> =
    CompletableDeferred<T>().also { destination ->
        caller?.invokeOnCompletion { error ->
            if (error is CancellationException) destination.cancel(error)
        }
    }

public open class TjnObject internal constructor(
    internal val owner: TjnEngine,
    internal var nativeHandle: Long,
) : Closeable {
    private val released = AtomicBoolean(false)
    public val handle: Long get() = nativeHandle
    public fun setPosition(x: Float, y: Float, z: Float): Unit = owner.command(this) {
        owner.check(NativeBindings.setPosition(owner.nativeHandle, nativeHandle, x, y, z), "object.setPosition")
    }
    public fun setQuaternion(x: Float, y: Float, z: Float, w: Float): Unit = owner.command(this) {
        owner.check(NativeBindings.setQuaternion(owner.nativeHandle, nativeHandle, x, y, z, w), "object.setQuaternion")
    }
    final override fun close() {
        if (!released.compareAndSet(false, true)) return
        val handle = nativeHandle; nativeHandle = 0
        if (!owner.isClosed && handle != 0L) owner.post { NativeBindings.releaseHandle(owner.nativeHandle, handle) }
    }
    internal fun requireOpen() { if (released.get() || nativeHandle == 0L) throw TjnEngineException(6, "object access") }
}

public class TjnScene internal constructor(owner: TjnEngine, handle: Long) : TjnObject(owner, handle) {
    public fun add(child: TjnObject): Unit = owner.command(this, child) {
        owner.check(NativeBindings.add(owner.nativeHandle, nativeHandle, child.nativeHandle), "scene.add")
    }
    public fun remove(child: TjnObject): Unit = owner.command(this, child) {
        owner.check(NativeBindings.remove(owner.nativeHandle, nativeHandle, child.nativeHandle), "scene.remove")
    }
}
public open class TjnCamera internal constructor(owner: TjnEngine, handle: Long) : TjnObject(owner, handle)
public class TjnPerspectiveCamera internal constructor(owner: TjnEngine, handle: Long) : TjnCamera(owner, handle) {
    public fun lookAt(x: Float, y: Float, z: Float): Unit = owner.command(this) {
        owner.check(NativeBindings.lookAt(owner.nativeHandle, nativeHandle, x, y, z), "camera.lookAt")
    }
}
public class TjnGeometry internal constructor(owner: TjnEngine, handle: Long) : TjnObject(owner, handle)
public class TjnMaterial internal constructor(owner: TjnEngine, handle: Long) : TjnObject(owner, handle) {
    public fun setBaseColorTexture(texture: TjnTexture): Unit = owner.command(this, texture) {
        owner.check(NativeBindings.setBaseColorTexture(owner.nativeHandle, nativeHandle, texture.nativeHandle), "material.texture")
    }
}
public class TjnMesh internal constructor(owner: TjnEngine, handle: Long) : TjnObject(owner, handle)
public class TjnLight internal constructor(owner: TjnEngine, handle: Long) : TjnObject(owner, handle)
public class TjnTexture internal constructor(owner: TjnEngine, handle: Long) : TjnObject(owner, handle)
public class TjnRenderTarget internal constructor(owner: TjnEngine, handle: Long) : TjnObject(owner, handle)
public class TjnOrbitControls internal constructor(owner: TjnEngine, handle: Long) : TjnObject(owner, handle) {
    public fun wheel(deltaPixels: Float): Unit = owner.command(this) {
        owner.check(NativeBindings.wheel(owner.nativeHandle, nativeHandle, deltaPixels), "controls.wheel")
    }
}
public class LoadedResource internal constructor(owner: TjnEngine, handle: Long) : TjnObject(owner, handle) {
    public fun root(): TjnObject = owner.command(this) { TjnObject(owner, owner.handle(NativeBindings.resourceRoot(owner.nativeHandle, nativeHandle), "resource.root")) }
    public fun playAnimation(clipName: String): TjnAnimationAction = owner.command(this) {
        TjnAnimationAction(owner, owner.handle(NativeBindings.playAnimation(owner.nativeHandle, nativeHandle, clipName), "animation.play"))
    }
}
public class TjnAnimationAction internal constructor(owner: TjnEngine, handle: Long) : TjnObject(owner, handle) {
    public fun stop(): Unit = owner.command(this) { owner.check(NativeBindings.stopAnimation(owner.nativeHandle, nativeHandle), "animation.stop") }
}

public class TjnEngine private constructor(
    context: Context,
    configuration: EngineConfiguration,
) : Closeable, ComponentCallbacks2 {
    private val applicationContext = context.applicationContext
    private val engineHandler: Handler = EngineDispatcher.retain()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val closed = AtomicBoolean(false)
    private val frameScheduled = AtomicBoolean(false)
    private val attached = AtomicBoolean(false)
    private val sessionIdentity = serial.incrementAndGet()
    private var boundView: TjnEngineView? = null
    private var boundSurfaceView: TjnEngineSurfaceView? = null
    private var inputControls: Long = 0
    private var renderScene: Long = 0
    private var renderCamera: Long = 0
    private var lastFrameNanos = 0L
    internal val nativeHandle: Long
    internal val isClosed: Boolean get() = closed.get()

    private val mutableState = MutableStateFlow(EngineState.Detached)
    private val mutableEvents = MutableSharedFlow<EngineEvent>(extraBufferCapacity = 64)
    private val mutableCapabilities = MutableStateFlow<RuntimeCapabilities?>(null)
    public val state: StateFlow<EngineState> = mutableState
    public val events: SharedFlow<EngineEvent> = mutableEvents
    public val capabilities: StateFlow<RuntimeCapabilities?> = mutableCapabilities

    private sealed interface Pending {
        data class Resource(val value: CompletableDeferred<LoadedResource>) : Pending
        data class Capture(val value: CompletableDeferred<Bitmap>) : Pending
    }
    private val pending = ConcurrentHashMap<Long, Pending>()

    init {
        try {
            nativeHandle = EngineDispatcher.call {
                NativeBindings.create(configuration.eventCapacity, configuration.memoryBudgetBytes, configuration.quality)
            }.also { handle(it, "engine.create") }
            applicationContext.registerComponentCallbacks(this)
            updateCapabilities()
        } catch (error: Throwable) {
            EngineDispatcher.release(); throw error
        }
    }

    public companion object {
        private val serial = AtomicLong(0)
        public fun create(context: Context, configuration: EngineConfiguration = EngineConfiguration.StandardMobile): Result<TjnEngine> =
            runCatching { TjnEngine(context, configuration) }
    }

    public fun createScene(): TjnScene = call { TjnScene(this, handle(NativeBindings.createScene(nativeHandle), "scene.create")) }
    public fun createPerspectiveCamera(config: PerspectiveCameraConfiguration): TjnPerspectiveCamera = call {
        TjnPerspectiveCamera(this, handle(NativeBindings.createPerspectiveCamera(nativeHandle, config.fovDegrees,
            config.aspect, config.nearPlane, config.farPlane), "camera.create"))
    }
    public fun createGeometry(descriptor: GeometryDescriptor): TjnGeometry = call {
        when (descriptor) { is GeometryDescriptor.Box -> TjnGeometry(this,
            handle(NativeBindings.createBox(nativeHandle, descriptor.width, descriptor.height, descriptor.depth), "geometry.create")) }
    }
    public fun createMaterial(descriptor: MaterialDescriptor): TjnMaterial = call {
        val value = when (descriptor) {
            is MaterialDescriptor.Basic -> NativeBindings.createMaterial(nativeHandle, false, descriptor.colorRgb, 0f, 1f)
            is MaterialDescriptor.Standard -> NativeBindings.createMaterial(nativeHandle, true, descriptor.colorRgb,
                descriptor.metalness, descriptor.roughness)
        }
        TjnMaterial(this, handle(value, "material.create"))
    }
    public fun createMesh(geometry: TjnGeometry, material: TjnMaterial): TjnMesh = command(geometry, material) {
        TjnMesh(this, handle(NativeBindings.createMesh(nativeHandle, geometry.nativeHandle, material.nativeHandle), "mesh.create"))
    }
    public fun createLight(descriptor: LightDescriptor): TjnLight = call {
        val values = when (descriptor) {
            is LightDescriptor.Ambient -> arrayOf(9, descriptor.colorRgb, descriptor.intensity, 0f)
            is LightDescriptor.Directional -> arrayOf(10, descriptor.colorRgb, descriptor.intensity, 0f)
            is LightDescriptor.Point -> arrayOf(11, descriptor.colorRgb, descriptor.intensity, descriptor.distance)
        }
        TjnLight(this, handle(NativeBindings.createLight(nativeHandle, values[0] as Int, values[1] as Int,
            values[2] as Float, values[3] as Float), "light.create"))
    }
    public fun createTexture(width: Int, height: Int, rgba: ByteArray, srgb: Boolean = true): TjnTexture = call {
        require(rgba.size == width * height * 4) { "RGBA byte count does not match dimensions" }
        TjnTexture(this, handle(NativeBindings.createTexture(nativeHandle, width, height, rgba, srgb), "texture.create"))
    }
    public fun createRenderTarget(width: Int, height: Int, hdr: Boolean = false): TjnRenderTarget = call {
        TjnRenderTarget(this, handle(NativeBindings.createRenderTarget(nativeHandle, width, height, hdr), "renderTarget.create"))
    }
    public fun createOrbitControls(camera: TjnPerspectiveCamera, targetX: Float = 0f,
                                   targetY: Float = 0f, targetZ: Float = 0f): TjnOrbitControls = command(camera) {
        val value = handle(NativeBindings.createOrbitControls(nativeHandle, camera.nativeHandle,
            targetX, targetY, targetZ), "controls.create")
        inputControls = value
        TjnOrbitControls(this, value)
    }
    public fun render(scene: TjnScene, camera: TjnCamera) {
        ensureOpen()
        requireOwned(scene); requireOwned(camera)
        val sceneHandle = scene.nativeHandle
        val cameraHandle = camera.nativeHandle
        postFrameCommand("renderer.render") {
            renderScene = sceneHandle
            renderCamera = cameraHandle
            renderSelected()
        }
    }

    public suspend fun load(request: AssetRequest): LoadedResource {
        val bytes = withContext(Dispatchers.IO) {
            applicationContext.contentResolver.openInputStream(request.uri)?.use { it.readBytes() }
                ?: throw IllegalArgumentException("Cannot open ${request.uri}")
        }
        return awaitRequest("resource.load", {
            NativeBindings.loadGlb(nativeHandle, bytes)
        }) { Pending.Resource(it) }
    }
    public suspend fun capture(options: CaptureOptions = CaptureOptions()): Bitmap {
        options.renderTarget?.let { requireOwned(it) }
        val renderTarget = options.renderTarget?.nativeHandle ?: 0
        return awaitRequest("capture.request", {
            NativeBindings.requestCapture(nativeHandle, renderTarget)
        }) { Pending.Capture(it) }
    }

    public fun attach(view: TjnEngineView) {
        checkMainThread(); ensureOpen()
        if (boundView === view) return
        boundView?.bind(null)
        boundSurfaceView?.bind(null); boundSurfaceView = null
        boundView = view; view.bind(this)
    }
    public fun attach(view: TjnEngineSurfaceView) {
        checkMainThread(); ensureOpen()
        if (boundSurfaceView === view) return
        boundSurfaceView?.bind(null)
        boundView?.bind(null); boundView = null
        boundSurfaceView = view; view.bind(this)
    }
    public fun detach() {
        checkMainThread(); boundView?.bind(null); boundView = null
        boundSurfaceView?.bind(null); boundSurfaceView = null
        surfaceDestroyed()
    }
    public fun pause(reason: SuspensionReason = SuspensionReason.Explicit) { post { NativeBindings.pause(nativeHandle, reason.value) } }
    public fun resume(reason: SuspensionReason = SuspensionReason.Explicit) { post { NativeBindings.resume(nativeHandle, reason.value) } }
    public fun trimMemory(level: TrimMemoryLevel) { if (level == TrimMemoryLevel.Critical) frameScheduled.set(false) }

    internal fun surfaceAvailable(surface: Surface, logicalWidth: Int, logicalHeight: Int,
                                  framebufferWidth: Int, framebufferHeight: Int, dpr: Float) {
        ensureOpen()
        mutableState.value = EngineState.Attaching
        postFrameCommand("surface.attach") {
            check(NativeBindings.attach(nativeHandle, surface, logicalWidth, logicalHeight,
                framebufferWidth, framebufferHeight, dpr), "surface.attach")
            attached.set(true)
            if (renderSelected()) mainHandler.post { scheduleFrame() }
        }
    }
    internal fun surfaceChanged(logicalWidth: Int, logicalHeight: Int,
                                framebufferWidth: Int, framebufferHeight: Int, dpr: Float) { postFrameCommand("surface.resize") {
        if (attached.get()) {
            check(NativeBindings.resize(nativeHandle, logicalWidth, logicalHeight,
                framebufferWidth, framebufferHeight, dpr), "surface.resize")
            renderSelected()
        }
    } }
    internal fun surfaceDestroyed() {
        frameScheduled.set(false)
        if (!closed.get()) EngineDispatcher.call {
            if (attached.getAndSet(false)) NativeBindings.detach(nativeHandle)
            lastFrameNanos = 0L
        }
    }
    internal fun pointer(kind: Int, id: Int, x: Float, y: Float, pressure: Float, buttons: Int, modifiers: Int) {
        post { NativeBindings.pointer(nativeHandle, kind, id, x, y, pressure, buttons, modifiers) }
    }
    internal fun wheel(deltaPixels: Float) {
        val controls = inputControls
        if (controls != 0L) post { NativeBindings.wheel(nativeHandle, controls, deltaPixels) }
    }

    private fun scheduleFrame() {
        if (closed.get() || !attached.get() || !frameScheduled.compareAndSet(false, true)) return
        Choreographer.getInstance().postFrameCallback { frameNanos ->
            frameScheduled.set(false)
            if (closed.get() || !attached.get()) return@postFrameCallback
            engineHandler.post {
                val delta = if (lastFrameNanos == 0L) 0.0 else (frameNanos - lastFrameNanos) / 1_000_000_000.0
                lastFrameNanos = frameNanos
                val tickStatus = NativeBindings.tick(nativeHandle, frameNanos / 1_000_000_000.0, delta)
                val keepRunning = when (tickStatus) {
                    TjnStatus.OK -> renderSelected()
                    TjnStatus.INVALID_STATE, TjnStatus.SURFACE_UNAVAILABLE -> true
                    else -> failFrame(TjnEngineException(tickStatus, "engine.tick"))
                }
                drainEvents()
                if (keepRunning) mainHandler.post { scheduleFrame() }
            }
        }
    }
    private fun renderSelected(): Boolean {
        if (!attached.get() || renderScene == 0L || renderCamera == 0L) return true
        val status = NativeBindings.render(nativeHandle, renderScene, renderCamera)
        return when (status) {
            TjnStatus.OK, TjnStatus.INVALID_STATE, TjnStatus.SURFACE_UNAVAILABLE -> true
            else -> failFrame(TjnEngineException(status, "renderer.render"))
        }
    }
    private fun postFrameCommand(operation: String, block: () -> Unit) {
        post {
            try {
                block()
            } catch (error: TjnEngineException) {
                failFrame(error)
            } catch (error: Throwable) {
                failFrame(TjnEngineException(TjnStatus.INTERNAL, operation).also { it.initCause(error) })
            }
        }
    }
    private fun failFrame(error: TjnEngineException): Boolean {
        frameScheduled.set(false)
        Log.e("TjnEngine", "frame loop stopped", error)
        mainHandler.post {
            mutableState.value = EngineState.Failed
            mutableEvents.tryEmit(EngineEvent(0, 0, 0, error.status, 0, 0))
        }
        return false
    }
    private fun drainEvents() {
        val raw = LongArray(8)
        while (NativeBindings.pollEvent(nativeHandle, raw) == 0) {
            val event = EngineEvent(raw[0].toInt(), raw[2], raw[3], raw[4].toInt(), raw[5], raw[6])
            mainHandler.post { publishEvent(event) }
        }
    }
    private fun publishEvent(event: EngineEvent) {
        mutableEvents.tryEmit(event)
        if (event.type == 1) mutableState.value = EngineState.entries.getOrElse(event.value1.toInt()) { mutableState.value }
        if (event.type != 4 && event.type != 7) return
        when (val value = pending.remove(event.requestId)) {
            is Pending.Resource -> if (event.status == 0) value.value.complete(LoadedResource(this, event.objectHandle))
                else value.value.completeExceptionally(TjnEngineException(event.status, "resource.load"))
            is Pending.Capture -> if (event.status == 0) completeCapture(event.requestId, value.value)
                else value.value.completeExceptionally(TjnEngineException(event.status, "capture"))
            null -> Unit
        }
    }
    private fun completeCapture(request: Long, destination: CompletableDeferred<Bitmap>) {
        if (closed.get()) {
            destination.completeExceptionally(CancellationException("Engine closed"))
            return
        }
        engineHandler.post {
            if (closed.get()) {
                destination.completeExceptionally(CancellationException("Engine closed"))
                return@post
            }
            runCatching {
                val result = NativeBindings.copyCapture(nativeHandle, request)
                Bitmap.createBitmap(result.width, result.height, Bitmap.Config.ARGB_8888).also {
                    it.copyPixelsFromBuffer(ByteBuffer.wrap(result.rgba))
                }
            }.onSuccess(destination::complete).onFailure(destination::completeExceptionally)
        }
    }
    private suspend fun <T> awaitRequest(operation: String, start: () -> Long,
                                         value: (CompletableDeferred<T>) -> Pending): T {
        ensureOpen()
        // Propagate caller cancellation without parenting the request deferred.
        // A child deferred would also propagate a native request failure back
        // into the caller Job before await() can catch it.
        val destination = requestDeferred<T>(coroutineContext[Job])
        val request = AtomicLong(0)
        engineHandler.post {
            if (closed.get()) {
                destination.completeExceptionally(CancellationException("Engine closed"))
                return@post
            }
            if (destination.isCancelled) return@post
            try {
                val id = handle(start(), operation)
                request.set(id)
                pending[id] = value(destination)
                if (destination.isCancelled && pending.remove(id) != null) {
                    NativeBindings.cancel(nativeHandle, id)
                }
            } catch (error: Throwable) {
                destination.completeExceptionally(error)
            }
        }
        destination.invokeOnCompletion { error ->
            if (error is CancellationException) engineHandler.post {
                val id = request.get()
                if (id != 0L && pending.remove(id) != null && !closed.get()) {
                    NativeBindings.cancel(nativeHandle, id)
                }
            }
        }
        return destination.await()
    }
    private fun updateCapabilities() {
        val raw = call { NativeBindings.capabilities(nativeHandle) }
        mutableCapabilities.value = RuntimeCapabilities(raw[0].toInt(), raw[1].toInt(), raw[2].toInt(), raw[3])
    }

    internal fun post(block: () -> Unit) { if (!closed.get()) engineHandler.post { if (!closed.get()) block() } }
    internal fun <T> call(block: () -> T): T { ensureOpen(); return EngineDispatcher.call(block) }
    internal fun <T> command(vararg objects: TjnObject, block: () -> T): T {
        objects.forEach { requireOwned(it) }; return call(block)
    }
    internal fun requireOwned(value: TjnObject) {
        if (value.owner.sessionIdentity != sessionIdentity) throw TjnEngineException(8, "cross-session object")
        value.requireOpen()
    }
    internal fun check(status: Int, operation: String) { if (status != 0) throw TjnEngineException(status, operation) }
    internal fun handle(value: Long, operation: String): Long { if (value == 0L) throw TjnEngineException(19, operation); return value }
    private fun ensureOpen() { if (closed.get()) throw TjnEngineException(6, "engine access") }
    private fun checkMainThread() { check(Looper.myLooper() == Looper.getMainLooper()) { "View lifecycle must run on main thread" } }

    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        frameScheduled.set(false)
        boundView?.bind(null); boundView = null
        boundSurfaceView?.bind(null); boundSurfaceView = null
        applicationContext.unregisterComponentCallbacks(this)
        EngineDispatcher.call {
            if (attached.getAndSet(false)) NativeBindings.detach(nativeHandle)
            renderScene = 0L; renderCamera = 0L; lastFrameNanos = 0L
            pending.values.forEach { value ->
                val error = CancellationException("Engine closed")
                when (value) { is Pending.Resource -> value.value.completeExceptionally(error); is Pending.Capture -> value.value.completeExceptionally(error) }
            }
            pending.clear(); NativeBindings.destroy(nativeHandle)
        }
        mutableState.value = EngineState.Destroyed
        EngineDispatcher.release()
    }

    override fun onTrimMemory(level: Int) {
        trimMemory(if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL) TrimMemoryLevel.Critical else TrimMemoryLevel.Moderate)
    }
    override fun onLowMemory() { trimMemory(TrimMemoryLevel.Critical) }
    override fun onConfigurationChanged(newConfig: Configuration) = Unit
}
