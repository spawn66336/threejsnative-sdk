package dev.threejsnative.engine

import android.view.Surface
import java.nio.ByteBuffer

internal object NativeBindings {
    init { System.loadLibrary("tjn_engine") }

    external fun create(eventCapacity: Int, memoryBudgetBytes: Long, quality: Int): Long
    external fun attach(engine: Long, surface: Surface, logicalWidth: Int, logicalHeight: Int,
                        framebufferWidth: Int, framebufferHeight: Int, dpr: Float): Int
    external fun resize(engine: Long, logicalWidth: Int, logicalHeight: Int,
                        framebufferWidth: Int, framebufferHeight: Int, dpr: Float): Int
    external fun tick(engine: Long, timeSeconds: Double, deltaSeconds: Double): Int
    external fun pause(engine: Long, reason: Int): Int
    external fun resume(engine: Long, reason: Int): Int
    external fun detach(engine: Long): Int
    external fun destroy(engine: Long): Int
    external fun pollEvent(engine: Long, output: LongArray): Int
    external fun cancel(engine: Long, request: Long): Int
    external fun releaseHandle(engine: Long, handle: Long): Int
    external fun createScene(engine: Long): Long
    external fun createPerspectiveCamera(engine: Long, fov: Float, aspect: Float, near: Float, far: Float): Long
    external fun createBox(engine: Long, width: Float, height: Float, depth: Float): Long
    external fun createMaterial(engine: Long, standard: Boolean, color: Int, metalness: Float, roughness: Float): Long
    external fun createMesh(engine: Long, geometry: Long, material: Long): Long
    external fun createLight(engine: Long, type: Int, color: Int, intensity: Float, distance: Float): Long
    external fun createTexture(engine: Long, width: Int, height: Int, rgba: ByteArray, srgb: Boolean): Long
    external fun createRenderTarget(engine: Long, width: Int, height: Int, hdr: Boolean): Long
    external fun createOrbitControls(engine: Long, camera: Long, targetX: Float, targetY: Float, targetZ: Float): Long
    external fun add(engine: Long, parent: Long, child: Long): Int
    external fun remove(engine: Long, parent: Long, child: Long): Int
    external fun setPosition(engine: Long, objectHandle: Long, x: Float, y: Float, z: Float): Int
    external fun setQuaternion(engine: Long, objectHandle: Long, x: Float, y: Float, z: Float, w: Float): Int
    external fun lookAt(engine: Long, camera: Long, x: Float, y: Float, z: Float): Int
    external fun setBaseColorTexture(engine: Long, material: Long, texture: Long): Int
    external fun render(engine: Long, scene: Long, camera: Long): Int
    external fun loadGlb(engine: Long, bytes: ByteArray): Long
    external fun resourceRoot(engine: Long, resource: Long): Long
    external fun playAnimation(engine: Long, resource: Long, clipName: String): Long
    external fun stopAnimation(engine: Long, action: Long): Int
    external fun requestCapture(engine: Long, renderTarget: Long): Long
    external fun copyCapture(engine: Long, request: Long): CapturePayload
    external fun capabilities(engine: Long): LongArray
    external fun pointer(engine: Long, kind: Int, pointerId: Int, x: Float, y: Float,
                         pressure: Float, buttons: Int, modifiers: Int): Int
    external fun wheel(engine: Long, controls: Long, deltaPixels: Float): Int
}

internal data class CapturePayload(
    val rgba: ByteArray,
    val width: Int,
    val height: Int,
    val stride: Int,
)
