package dev.threejsnative.engine

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.compose.LocalLifecycleOwner

@Composable
public fun TjnEngineSurface(engine: TjnEngine, modifier: Modifier = Modifier) {
    val lifecycleOwner = LocalLifecycleOwner.current
    AndroidView(
        modifier = modifier,
        factory = { context -> TjnEngineView(context).also(engine::attach) },
        update = { engine.attach(it) },
    )
    DisposableEffect(engine, lifecycleOwner) {
        val observer = object : DefaultLifecycleObserver {
            override fun onResume(owner: LifecycleOwner) = engine.resume(SuspensionReason.ApplicationInactive)
            override fun onPause(owner: LifecycleOwner) = engine.pause(SuspensionReason.ApplicationInactive)
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer); engine.detach() }
    }
}
