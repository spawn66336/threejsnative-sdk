package dev.threejsnative.engine

import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import java.util.concurrent.CountDownLatch
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

internal object EngineDispatcher {
    private val references = AtomicInteger(0)
    private var thread: HandlerThread? = null
    private var handler: Handler? = null

    @Synchronized fun retain(): Handler {
        if (thread == null) {
            thread = HandlerThread("TjnEngine").also { it.start() }
            handler = Handler(thread!!.looper)
        }
        references.incrementAndGet()
        return handler!!
    }

    @Synchronized fun release() {
        if (references.decrementAndGet() == 0) {
            thread?.quitSafely(); thread = null; handler = null
        }
    }

    fun <T> call(block: () -> T): T {
        val target = synchronized(this) { handler ?: error("Engine dispatcher is closed") }
        if (Looper.myLooper() == target.looper) return block()
        val value = AtomicReference<T>()
        val failure = AtomicReference<Throwable>()
        val barrier = CountDownLatch(1)
        target.post { try { value.set(block()) } catch (error: Throwable) { failure.set(error) } finally { barrier.countDown() } }
        barrier.await(); failure.get()?.let { throw it }; return value.get()
    }
}
